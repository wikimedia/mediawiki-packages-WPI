<?php
$messages = array();

$messages['en'] = array(
	'windowsazuresdk-desc' => 'Provides the [http://phpazure.codeplex.com/ PHPAzure] SDK created by [http://www.realdolmen.com/ REALDOLMEN]'
);

/** Message documentation (Message documentation)
 * @author Purodha
 * @author Shirayuki
 */
$messages['qqq'] = array(
	'windowsazuresdk-desc' => '{{desc|name=Windows Azure SDK|url=http://www.mediawiki.org/wiki/Extension:WindowsAzureSDK}}',
);

/** Belarusian (Taraškievica orthography) (беларуская (тарашкевіца)‎)
 * @author Wizardist
 */
$messages['be-tarask'] = array(
	'windowsazuresdk-desc' => 'Прадстаўляе [http://phpazure.codeplex.com/ PHPAzure] SDK, створаны [http://www.realdolmen.com/ REALDOLMEN]',
);

/** Breton (brezhoneg)
 * @author Fulup
 */
$messages['br'] = array(
	'windowsazuresdk-desc' => 'Pourchas a ra an SDK [http://phpazure.codeplex.com/ PHPAzure] krouet gant [http://www.realdolmen.com/ REALDOLMEN]',
);

/** Danish (dansk)
 * @author Hylle
 */
$messages['da'] = array(
	'windowsazuresdk-desc' => 'Giver adgang til [http://phpazure.codeplex.com/ PHPAzure] SDK lavet af [http://www.realdolmen.com/ REALDOLMEN]',
);

/** German (Deutsch)
 * @author Kghbln
 */
$messages['de'] = array(
	'windowsazuresdk-desc' => 'Stellt das von [http://www.realdolmen.com/ RealDolmen] entwickelte [http://phpazure.codeplex.com/ Windows Azure SDK für PHP] bereit',
);

/** Lower Sorbian (dolnoserbski)
 * @author Michawiki
 */
$messages['dsb'] = array(
	'windowsazuresdk-desc' => 'Staja [http://phpazure.codeplex.com/ PHPAzure]-SDK napórany wót [http://www.realdolmen.com/ REALDOLMEN] k dispoziciji.',
);

/** Spanish (español)
 * @author Armando-Martin
 */
$messages['es'] = array(
	'windowsazuresdk-desc' => 'Proporciona el SDK [http://phpazure.codeplex.com/ PHPAzure] creado por [http://www.realdolmen.com/ REALDOLMEN]',
);

/** Persian (فارسی)
 * @author Reza1615
 */
$messages['fa'] = array(
	'windowsazuresdk-desc' => '[http://phpazure.codeplex.com/ PHPAzure] فراهم می‌کند SDK ساخته شده توسط [http://www.realdolmen.com/ REALDOLMEN]',
);

/** French (français)
 * @author Gomoko
 */
$messages['fr'] = array(
	'windowsazuresdk-desc' => 'Fournit le SDK [http://phpazure.codeplex.com/ PHPAzure] créé par [http://www.realdolmen.com/ REALDOLMEN].',
);

/** Galician (galego)
 * @author Toliño
 */
$messages['gl'] = array(
	'windowsazuresdk-desc' => 'Proporciona o SDK [http://phpazure.codeplex.com/ PHPAzure] creado por [http://www.realdolmen.com/ REALDOLMEN]',
);

/** Hebrew (עברית)
 * @author Amire80
 */
$messages['he'] = array(
	'windowsazuresdk-desc' => 'תמיכה בערכת הפיתוח [http://phpazure.codeplex.com/ PHPAzure] מאת [http://www.realdolmen.com/ REALDOLMEN]',
);

/** Upper Sorbian (hornjoserbsce)
 * @author Michawiki
 */
$messages['hsb'] = array(
	'windowsazuresdk-desc' => 'Staja [http://phpazure.codeplex.com/ PHPAzure]-SDK wutworjeny wot [http://www.realdolmen.com/ REALDOLMEN] k dispoziciji.',
);

/** Interlingua (interlingua)
 * @author McDutchie
 */
$messages['ia'] = array(
	'windowsazuresdk-desc' => 'Provide le SDK de [http://phpazure.codeplex.com/ PHPAzure] create per [http://www.realdolmen.com/ REALDOLMEN].',
);

/** Italian (italiano)
 * @author Beta16
 */
$messages['it'] = array(
	'windowsazuresdk-desc' => "Fornisce l'SDK [http://phpazure.codeplex.com/ PHPAzure] creato da [http://www.realdolmen.com/ REALDOLMEN]",
);

/** Japanese (日本語)
 * @author Shirayuki
 */
$messages['ja'] = array(
	'windowsazuresdk-desc' => '[http://www.realdolmen.com/ REALDOLMEN] が作成した [http://phpazure.codeplex.com/ PHPAzure] SDK を提供する',
);

/** Korean (한국어)
 * @author 아라
 */
$messages['ko'] = array(
	'windowsazuresdk-desc' => '[http://www.realdolmen.com/ REALDOLMEN]이 만든 [http://phpazure.codeplex.com/ PHPAzure] SDK를 제공',
);

/** Colognian (Ripoarisch)
 * @author Purodha
 */
$messages['ksh'] = array(
	'windowsazuresdk-desc' => 'Deiht et <i lang="en">[http://phpazure.codeplex.com/ PHPAzure] SDK</i> vum <i lang="en">[http://www.realdolmen.com/ REALDOLMEN]</i> en et Wiki.',
);

/** Macedonian (македонски)
 * @author Bjankuloski06
 */
$messages['mk'] = array(
	'windowsazuresdk-desc' => 'Го дава приборот за програмски развој [http://phpazure.codeplex.com/ PHPAzure] од [http://www.realdolmen.com/ REALDOLMEN].',
);

/** Malay (Bahasa Melayu)
 * @author Anakmalaysia
 */
$messages['ms'] = array(
	'windowsazuresdk-desc' => 'Membekalkan SDK [http://phpazure.codeplex.com/ PHPAzure] ciptaan [http://www.realdolmen.com/ REALDOLMEN]',
);

/** Dutch (Nederlands)
 * @author Siebrand
 */
$messages['nl'] = array(
	'windowsazuresdk-desc' => 'Biedt de [http://phpazure.codeplex.com/ PHPAzure] SDK gemaakt door [http://www.realdolmen.com/ REALDOLMEN]',
);

/** Polish (polski)
 * @author BeginaFelicysym
 */
$messages['pl'] = array(
	'windowsazuresdk-desc' => 'Zapewnia SDK [http://phpazure.codeplex.com/ PHPAzure] utworzony przez [http://www.realdolmen.com/ REALDOLMEN]',
);

/** Piedmontese (Piemontèis)
 * @author Dragonòt
 */
$messages['pms'] = array(
	'windowsazuresdk-desc' => 'A dà ël [http://phpazure.codeplex.com/ PHPAzure] SDK creà da [http://www.realdolmen.com/ REALDOLMEN]',
);

/** tarandíne (tarandíne)
 * @author Joetaras
 */
$messages['roa-tara'] = array(
	'windowsazuresdk-desc' => "Dèje l'SDK [http://phpazure.codeplex.com/ PHPAzure] ccrejate da [http://www.realdolmen.com/ REALDOLMEN]",
);

/** Tagalog (Tagalog)
 * @author AnakngAraw
 */
$messages['tl'] = array(
	'windowsazuresdk-desc' => 'Nagbibigay ng SDK ng [http://phpazure.codeplex.com/ PHPAzure] na nilikha ng [http://www.realdolmen.com/ REALDOLMEN]',
);

/** Ukrainian (українська)
 * @author Base
 */
$messages['uk'] = array(
	'windowsazuresdk-desc' => 'Представляє [http://phpazure.codeplex.com/ PHPAzure] SDK, створене [http://www.realdolmen.com/ REALDOLMEN]',
);

/** Simplified Chinese (中文（简体）‎)
 * @author Yfdyh000
 */
$messages['zh-hans'] = array(
	'windowsazuresdk-desc' => '提供[http://phpazure.codeplex.com/ PHPAzure] SDK，由[http://www.realdolmen.com/ REALDOLMEN]创建',
);
