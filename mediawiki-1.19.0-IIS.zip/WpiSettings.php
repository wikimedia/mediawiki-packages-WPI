<?php

$wgWPIOptionStore = array(
		//Screen1
		'lang' => 'PlaceholderForLanguage',
		//Screen2
		'dbserver' => 'PlaceholderForDbServer',
		'dbname' => 'PlaceholderForDbName',
		'dbprefix' => 'PlaceholderForDbPrefix',
		'dbuser' => 'PlaceholderForDbUsername',
		'dbpass' => 'PlaceholderForDbPassword',
		'installdbuser' => 'PlaceholderForDbAdminUsername',
		'installdbpass' => 'PlaceholderForDbAdminPassword',
		//Screen3
		'sitename' => 'PlaceholderForSitename',
		'adminname' => 'PlaceholderForAdminname',
		'pass' => 'PlaceholderForAdminpass',
		
		'scriptpath' => 'PlaceholderForScriptPath',
	    'enablefileupload' => 'PlaceholderForFileUpload',
		'usewindowsazure' => 'PlaceholderForUseAzure',
		'azurehost' => 'PlaceholderForAzureHost',
		'azureaccount' => 'PlaceholderForAzureAccount',
		'azurekey' => 'PlaceholderForAzureKey',
        'wikiId' => 'PlaceholderForWikiId'
	);