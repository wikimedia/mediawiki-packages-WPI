<?php

$messages = array();

$messages['en'] = array(
	'windowsazuresdk-desc' => 'Provides extensions with the ability to use the [https://github.com/WindowsAzure/azure-sdk-for-php Windows Azure SDK for PHP]'
);

/** Message documentation (Message documentation)
 * @author Shirayuki
 */
$messages['qqq'] = array(
	'windowsazuresdk-desc' => '{{desc|name=Windows Azure SDK|url=http://www.mediawiki.org/wiki/Extension:WindowsAzureSDK}}',
);

/** Asturian (asturianu)
 * @author Xuacu
 */
$messages['ast'] = array(
	'windowsazuresdk-desc' => 'Proporciona estensiones con capacidá pa usar [https://github.com/WindowsAzure/azure-sdk-for-php Windows Azure SDK pa PHP]',
);

/** Belarusian (Taraškievica orthography) (беларуская (тарашкевіца)‎)
 * @author Wizardist
 */
$messages['be-tarask'] = array(
	'windowsazuresdk-desc' => 'Прадстаўляе [http://phpazure.codeplex.com/ PHPAzure] SDK, створаны [http://www.realdolmen.com/ REALDOLMEN]', # Fuzzy
);

/** Breton (brezhoneg)
 * @author Fulup
 */
$messages['br'] = array(
	'windowsazuresdk-desc' => 'Pourchas a ra an SDK [http://phpazure.codeplex.com/ PHPAzure] krouet gant [http://www.realdolmen.com/ REALDOLMEN]', # Fuzzy
);

/** Danish (dansk)
 * @author Christian List
 * @author Hylle
 */
$messages['da'] = array(
	'windowsazuresdk-desc' => 'Giver adgang til at bruge [https://github.com/WindowsAzure/azure-sdk-for-php Windows Azure SDK for PHP]',
);

/** German (Deutsch)
 * @author Metalhead64
 */
$messages['de'] = array(
	'windowsazuresdk-desc' => 'Ergänzt Erweiterungen, die das [https://github.com/WindowsAzure/azure-sdk-for-php Windows-Azure-SDK für PHP] verwenden können',
);

/** Lower Sorbian (dolnoserbski)
 * @author Michawiki
 */
$messages['dsb'] = array(
	'windowsazuresdk-desc' => 'Staja [http://phpazure.codeplex.com/ PHPAzure]-SDK napórany wót [http://www.realdolmen.com/ REALDOLMEN] k dispoziciji.', # Fuzzy
);

/** Spanish (español)
 * @author Armando-Martin
 * @author Fitoschido
 */
$messages['es'] = array(
	'windowsazuresdk-desc' => 'Proporciona extensiones que pueden utilizar el [https://github.com/WindowsAzure/azure-sdk-for-php SDK de Windows Azure para PHP]',
);

/** Persian (فارسی)
 * @author Ebraminio
 * @author Reza1615
 */
$messages['fa'] = array(
	'windowsazuresdk-desc' => 'افزونه‌هایی برای توانایی استفاده از [https://github.com/WindowsAzure/azure-sdk-for-php کیت توسعهٔ ویندوز آژور برای پی‌اچ‌پی] فراهم می‌کند',
);

/** French (français)
 * @author Gomoko
 */
$messages['fr'] = array(
	'windowsazuresdk-desc' => 'Fournit des extensions avec la possibilité d’utiliser le [https://github.com/WindowsAzure/azure-sdk-for-php SDK Windows Azure pour PHP].',
);

/** Galician (galego)
 * @author Toliño
 */
$messages['gl'] = array(
	'windowsazuresdk-desc' => 'Proporciona extensións coa capacidade de utilizar o [https://github.com/WindowsAzure/azure-sdk-for-php Windows Azure SDK para PHP]',
);

/** Hebrew (עברית)
 * @author Amire80
 */
$messages['he'] = array(
	'windowsazuresdk-desc' => 'תמיכה בערכת הפיתוח [http://phpazure.codeplex.com/ PHPAzure] מאת [http://www.realdolmen.com/ REALDOLMEN]', # Fuzzy
);

/** Upper Sorbian (hornjoserbsce)
 * @author Michawiki
 */
$messages['hsb'] = array(
	'windowsazuresdk-desc' => 'Staja [http://phpazure.codeplex.com/ PHPAzure]-SDK wutworjeny wot [http://www.realdolmen.com/ REALDOLMEN] k dispoziciji.', # Fuzzy
);

/** Interlingua (interlingua)
 * @author McDutchie
 */
$messages['ia'] = array(
	'windowsazuresdk-desc' => 'Provide le SDK de [http://phpazure.codeplex.com/ PHPAzure] create per [http://www.realdolmen.com/ REALDOLMEN].', # Fuzzy
);

/** Italian (italiano)
 * @author Beta16
 */
$messages['it'] = array(
	'windowsazuresdk-desc' => 'Fornisce estensioni con la possibilità di utilizzare [https://github.com/WindowsAzure/azure-sdk-for-php Windows Azure SDK per PHP]',
);

/** Japanese (日本語)
 * @author Shirayuki
 */
$messages['ja'] = array(
	'windowsazuresdk-desc' => '[https://github.com/WindowsAzure/azure-sdk-for-php Windows Azure SDK for PHP] を使用できるように拡張する',
);

/** Korean (한국어)
 * @author 아라
 */
$messages['ko'] = array(
	'windowsazuresdk-desc' => '[https://github.com/WindowsAzure/azure-sdk-for-php Windows Azure SDK for PHP]를 사용할 수 있는 확장 기능을 제공합니다',
);

/** Colognian (Ripoarisch)
 * @author Purodha
 */
$messages['ksh'] = array(
	'windowsazuresdk-desc' => 'Määd et müjjelesch för Zosazprojramme, et <i lang="en" xml:lang="en">[https://github.com/WindowsAzure/azure-sdk-for-php Windows Azure SDK for PHP]</i> em Wiki ze bruche.',
);

/** Macedonian (македонски)
 * @author Bjankuloski06
 */
$messages['mk'] = array(
	'windowsazuresdk-desc' => 'Им дава на додатоците можност да го користат [https://github.com/WindowsAzure/azure-sdk-for-php Windows Azure SDK за PHP]',
);

/** Malay (Bahasa Melayu)
 * @author Anakmalaysia
 */
$messages['ms'] = array(
	'windowsazuresdk-desc' => 'Menyediakan ekstensi dengan kebolehan untuk menggunakan [https://github.com/WindowsAzure/azure-sdk-for-php Windows Azure SDK untuk PHP]',
);

/** Dutch (Nederlands)
 * @author Siebrand
 */
$messages['nl'] = array(
	'windowsazuresdk-desc' => 'Levert uitbreidingen met de mogelijkheid om de [https://github.com/WindowsAzure/azure-sdk-for-php Windows Azure SDK voor PHP] te gebruiken',
);

/** Occitan (occitan)
 * @author Cedric31
 */
$messages['oc'] = array(
	'windowsazuresdk-desc' => "Provesís d'extensions amb la possibilitat d’utilizar lo [https://github.com/WindowsAzure/azure-sdk-for-php SDK Windows Azure per PHP].",
);

/** Polish (polski)
 * @author BeginaFelicysym
 */
$messages['pl'] = array(
	'windowsazuresdk-desc' => 'Zapewnia SDK [http://phpazure.codeplex.com/ PHPAzure] utworzony przez [http://www.realdolmen.com/ REALDOLMEN]', # Fuzzy
);

/** Piedmontese (Piemontèis)
 * @author Dragonòt
 */
$messages['pms'] = array(
	'windowsazuresdk-desc' => 'A dà ël [http://phpazure.codeplex.com/ PHPAzure] SDK creà da [http://www.realdolmen.com/ REALDOLMEN]', # Fuzzy
);

/** Brazilian Portuguese (português do Brasil)
 * @author Cainamarques
 */
$messages['pt-br'] = array(
	'windowsazuresdk-desc' => 'Proporciona às extensões a habilidade de usar o [https://github.com/WindowsAzure/azure-sdk-for-php Windows Azure SDK for PHP]',
);

/** tarandíne (tarandíne)
 * @author Joetaras
 */
$messages['roa-tara'] = array(
	'windowsazuresdk-desc' => "Dèje l'estenziune cu l'abbilità de ausà l' [https://github.com/WindowsAzure/azure-sdk-for-php SDK de Windows Azure pe PHP]",
);

/** Russian (русский)
 * @author Okras
 */
$messages['ru'] = array(
	'windowsazuresdk-desc' => 'Предоставляет расширения, способные использовать [https://github.com/WindowsAzure/azure-sdk-for-php Windows Azure SDK для PHP]',
);

/** Tagalog (Tagalog)
 * @author AnakngAraw
 */
$messages['tl'] = array(
	'windowsazuresdk-desc' => 'Nagbibigay ng SDK ng [http://phpazure.codeplex.com/ PHPAzure] na nilikha ng [http://www.realdolmen.com/ REALDOLMEN]', # Fuzzy
);

/** Turkish (Türkçe)
 * @author Joseph
 */
$messages['tr'] = array(
	'windowsazuresdk-desc' => '[https://github.com/WindowsAzure/azure-sdk-for-php PHP için Windows Azure SDK] kullanma kaabiliyeti olan eklentiler sağlar',
);

/** Ukrainian (українська)
 * @author Andriykopanytsia
 * @author Base
 */
$messages['uk'] = array(
	'windowsazuresdk-desc' => 'Забезпечує розширення з можливістю використовувати   [https://github.com/WindowsAzure/azure-sdk-for-php Windows Azure SDK для PHP]',
);

/** Simplified Chinese (中文（简体）‎)
 * @author Liuxinyu970226
 * @author Qiyue2001
 * @author Yfdyh000
 */
$messages['zh-hans'] = array(
	'windowsazuresdk-desc' => '提供扩展与使用[https://github.com/WindowsAzure/azure-sdk-for-php 适用于PHP的Windows Azure SDK]的能力',
);

/** Traditional Chinese (中文（繁體）‎)
 * @author Justincheng12345
 */
$messages['zh-hant'] = array(
	'windowsazuresdk-desc' => '提供擴展與使用[HTTPs://github.com/WindowsAzure/azure-sdk-for-php Windows Azure SDK for PHP]的能力',
);
