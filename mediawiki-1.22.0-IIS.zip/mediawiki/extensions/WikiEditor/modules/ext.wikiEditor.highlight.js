/*
 * JavaScript for WikiEditor Highlighting
 */
jQuery( document ).ready( function ( $ ) {
	// Add highlight module
	$( '#wpTextbox1' ).wikiEditor( 'addModule', 'highlight' );
} );
