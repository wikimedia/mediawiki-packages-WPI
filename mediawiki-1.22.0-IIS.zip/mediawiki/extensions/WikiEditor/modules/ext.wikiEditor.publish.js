/*
 * JavaScript for WikiEditor Publish module
 */
jQuery( document ).ready( function ( $ ) {
	// Add publish module
	$( '#wpTextbox1' ).wikiEditor( 'addModule', 'publish' );
} );
