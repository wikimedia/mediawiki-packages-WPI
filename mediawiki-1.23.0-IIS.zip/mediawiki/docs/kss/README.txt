The Makefile, package.json, scripts, styleguide-template, and
mediawiki.ui/styleguide.md files and directories in here support the automatic
generation of CSS documentation from the source LESS files using kss for
node.js, https://github.com/kneath/kss
